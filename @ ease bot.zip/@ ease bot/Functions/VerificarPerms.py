import json

def verificar_permissao(user_id):
    try:
        with open("Database/perms.json", "r") as perms_file:
            perms = json.load(perms_file)
    except FileNotFoundError:
        return False

    return str(user_id) in perms