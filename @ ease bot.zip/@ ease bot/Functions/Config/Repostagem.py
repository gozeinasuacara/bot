from Commands.Admin.Plugins.Ticket import *
from Functions.Config.Produto  import *

async def SincronizarMensagemTicket(bot: commands.Bot):
    try:
        with open("config.json") as f:
            config = json.load(f)
            server = config["server"]
        
        server = int(server)
        server = bot.get_guild(server)
        
        if not server: return

        db = ObterDatabase()
        ticket = db["tickets"]["1"]
        categorias = ticket["categorias"]
        msg = db["tickets"]["1"]["embed"]["content"]
        title = db["tickets"]["1"]["embed"]["title"]
        desc = db["tickets"]["1"]["embed"]["desc"]
        banner = db["tickets"]["1"]["embed"]["banner"]
        color = db["tickets"]["1"]["embed"]["color"]
        color = int(color.lstrip("#"), 16)

        if not color: color = 0x00FFFF
        if not title: title = None
        if not desc: desc = None
        if not banner: banner = None

        embedPreview = disnake.Embed(
            title=title,
            description=desc,
            timestamp=datetime.now(),
            color=disnake.Color(color)
        )
        embedPreview.set_footer(text=server.name, icon_url=server.icon)
        embedPreview.set_image(url=banner)

        options = []
        if categorias:
            for categoriaID in categorias:
                categoria = ObterCategoria(categoriaID)
                if categoria:
                    options.append(
                        disnake.SelectOption(
                            label=categoria["title"],
                            emoji=categoria["emoji"],
                            value=categoriaID
                        )
                    )

        if not options:
            options = [
                disnake.SelectOption(
                    label="Nenhuma categoria disponível",
                    emoji="❌",
                    value="none"
                )
            ]

        select = disnake.ui.StringSelect(
            placeholder="Selecione uma categoria para abrir",
            custom_id="AbrirCategoriaDropdown",
            options=options,
            disabled=True if len(categorias) == 0 else False
        )

        
        novos_ids = []
        for ids in ticket["ids"]:
            channelID, messageID = ids.split("_")
            try:
                channel = bot.get_channel(int(channelID))
            except: return
            if channel:
                try:
                    oldmsg = await channel.fetch_message(int(messageID))
                    if oldmsg:
                        await oldmsg.delete()
                except: continue

                newmsg = await channel.send(content=msg, embed=embedPreview, components=select)
                novos_ids.append(f"{newmsg.channel.id}_{newmsg.id}")

        db["tickets"]["1"]["ids"] = novos_ids
        with open("Database/Tickets/ticket.json", "w") as f:
            json.dump(db, f, indent=4)
        
        return
    except: return

async def RepostagemMensagemProdutoVendas(bot: commands.Bot, produtoID):
    db = ObterDatabase()
    produto = db.get(produtoID)
    if not produto:
        return

    msg = produto.get("mensagem", "")
    embed, components = GerarPainelProduto(None, produtoID, bot)

    novos_ids = []
    for id_dict in produto.get("ids", []):
        try:
            channelID, messageID = list(id_dict.items())[0]
            channel = bot.get_channel(int(channelID))

            if not channel:
                continue
            oldmsg = await channel.fetch_message(int(messageID))
            if oldmsg:
                await oldmsg.delete()
        except:
            continue
        
        newmsg = await channel.send(content=msg, embed=embed, components=components)
        novos_ids.append({str(newmsg.channel.id): str(newmsg.id)})
    
    db[produtoID]["ids"] = novos_ids
    with open("Database/Vendas/produtos.json", "w") as f:
        json.dump(db, f, indent=4)
    
    return

async def RepostagemTodasMensagensVendas(bot: commands.Bot):
    db = ObterDatabase()
    for produtoID in db.keys():
        await RepostagemMensagemProdutoVendas(bot, produtoID)
    
    return