import disnake
from disnake import *
from disnake.ext import commands

import json
import sys
import os

from Events.OnBotStart import *
from Events.AcoesAutomaticas import executar_acoes

with open("config.json") as file:
    config = json.load(file)
    token = config["token"]
    owner = config["owner"]
    status = config["status"]
    bot = commands.Bot(command_prefix=commands.when_mentioned ,intents=disnake.Intents.all())

@bot.event
async def on_ready():
    os.system('cls') if os.name == "nt" else os.system("clear")
    print()
    print(banner)
    print()
    print(f"    conectado em {bot.user.name} | {bot.user.id}")
    print(f"    owner: {bot.owner}")
    print(f"    servidores: {len(bot.guilds)}")
    print(f"    latencia: {round(bot.latency * 1000)}ms")

    streaming_activity = disnake.Game(
        name=status,
    )

    await bot.change_presence(activity=streaming_activity)
    alterar_descricao_bot(bot)
    await startBotlogs(bot)
    bot.loop.create_task(executar_acoes(bot))


bot.load_extension("Commands.Admin.Perms")
bot.load_extension("Commands.Admin.Painel")

bot.load_extension("Commands.Admin.Plugins.BoasVindas")
bot.load_extension("Commands.Admin.Plugins.Ticket")
bot.load_extension("Commands.Admin.Plugins.Definicoes")
bot.load_extension("Commands.Admin.Plugins.Personalizacao")
bot.load_extension("Commands.Admin.Plugins.AcoesAutomaticas")
bot.load_extension("Commands.Admin.Plugins.Vendas")
bot.load_extension("Commands.Admin.Plugins.Carrinho")
bot.load_extension("Commands.Admin.Plugins.ECloud")
bot.load_extension("Commands.Admin.Rendimentos")
bot.load_extension("Commands.Admin.Rank")

bot.load_extension("Functions.Config.FormasPagamento.EFIBank")
bot.load_extension("Functions.Config.FormasPagamento.MercadoPago")
bot.load_extension("Functions.Config.FormasPagamento.SemiAuto")

bot.load_extension("Events.OnMemberJoin")
bot.load_extension("Events.OnRegister")
bot.load_extension("Events.OnMessage")

bot.load_extension("Commands.Mod.Ban")
bot.load_extension("Commands.Mod.Kick")
bot.load_extension("Commands.Mod.Lock")
bot.load_extension("Commands.Mod.Unlock")
bot.load_extension("Commands.Mod.Nuke")
bot.load_extension("Commands.Mod.ClsDM")
bot.load_extension("Commands.Mod.Product")

if __name__ == "__main__":
    bot.run(token)