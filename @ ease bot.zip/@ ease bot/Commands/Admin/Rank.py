import json
import disnake
from disnake.ext import commands
from datetime import datetime, timedelta

from Functions.CarregarEmojis import *
from Functions.VerificarPerms import *

def ObterDatabase():
    with open("Database/Vendas/historicos.json") as f:
        return json.load(f)

def ObterRanking():
    usuarios_gastos = {}
    vendas = ObterDatabase()
    for venda in vendas.values():
        usuario_id = venda['server']['usuario']
        valor_gasto = venda['info']['valorFinal']
        if usuario_id in usuarios_gastos:
            usuarios_gastos[usuario_id] += valor_gasto
        else:
            usuarios_gastos[usuario_id] = valor_gasto

    ranking = sorted(usuarios_gastos.items(), key=lambda x: x[1], reverse=True)
    return ranking

def criar_embed_ranking(pagina):
    embed = disnake.Embed(title="Ranking de Vendas", color=disnake.Color.blurple())
    inicio = (pagina - 1) * 5
    fim = inicio + 5
    ranking = ObterRanking()

    descricao = ""
    for i, (usuario_id, total_gasto) in enumerate(ranking[inicio:fim], start=inicio + 1):
        descricao += f"{i}. <@{usuario_id}> (`{usuario_id}`) — `R${total_gasto:.2f}`\n"

    embed.description = descricao if descricao else "Nenhum usuário no ranking."
    return embed

class RankCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.slash_command()
    async def rank(self, inter: disnake.ApplicationCommandInteraction):
        """
        Use to see the rank of users
        """
        pagina = 1
        embed = criar_embed_ranking(pagina)
        ranking = ObterRanking()

        botoes = [
            disnake.ui.Button(style=disnake.ButtonStyle.primary, label="Anterior", disabled=True),
            disnake.ui.Button(style=disnake.ButtonStyle.primary, label="Próximo", disabled=len(ranking) <= 5)
        ]
        await inter.response.send_message(embed=embed, components=[botoes])

        def check(button_inter):
            return button_inter.author == inter.author and button_inter.message == inter.message

        while True:
            try:
                button_inter = await self.bot.wait_for("button_click", check=check, timeout=120.0)
            except:
                await inter.edit_original_message(components=[])
                break

            if button_inter.component.label == "Anterior":
                pagina -= 1
            elif button_inter.component.label == "Próximo":
                pagina += 1

            embed = criar_embed_ranking(pagina)
            botoes[0].disabled = pagina == 1
            botoes[1].disabled = pagina * 5 >= len(ranking)
            await button_inter.response.edit_message(embed=embed, components=[botoes])

def setup(bot: commands.Bot):
    bot.add_cog(RankCommand(bot))
