import disnake
import json
from disnake.ext import commands
from disnake import *
from Functions.CarregarEmojis import *
from Functions.VerificarPerms import *
from datetime import datetime
import random
import string

def ObterDatabase():
    with open("Database/Tickets/ticket.json") as f:
        db = json.load(f)
        return db

def ObterCategoria(CategoriaID):
    with open("Database/Tickets/ticket.json") as f:
        db = json.load(f)
        categoria = db["tickets"]["1"]["categorias"][CategoriaID]
        return categoria

def ApagarCategoria(categoria_id):
    with open("Database/Tickets/ticket.json", "r") as file:
        data = json.load(file)
    
    categoria_removida = False
    for ticket_id, ticket_data in data.get("tickets", {}).items():
        categorias = ticket_data.get("categorias", {})
        if categoria_id in categorias:
            del categorias[categoria_id]
            categoria_removida = True
            break

    if categoria_removida:
        with open("Database/Tickets/ticket.json", "w") as file:
            json.dump(data, file, indent=4)

    else:
        return

def GerarString():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=13))

def CriarCategoria(title, emoji):
    categoriaID = GerarString()

    if emoji == "": emoji = None

    nova_categoria = {
        categoriaID: {
            "title": title,
            "emoji": emoji
        }
    }

    with open("Database/Tickets/ticket.json", "r") as f:
        db = json.load(f)

    db["tickets"]["1"]["categorias"].update(nova_categoria)

    with open("Database/Tickets/ticket.json", "w") as f:
        json.dump(db, f, indent=4)

def ObterPainelCategorias(inter: disnake.MessageInteraction):
    db = ObterDatabase()
    ticket = db["tickets"]["1"]
    categorias = ticket["categorias"]

    embed = disnake.Embed(
        title="Gerenciar Categorias | Ticket",
        description="""
Gerencie/crie categorias neste painel. É importante ressaltar que é possível ter várias categorias, mas somente um ticket.
        """,
        timestamp=datetime.now(),
        color=disnake.Color(0x00FFFF)
    )
    embed.add_field(name="Categorias Disponíveis", value=f"{caixa} ``{len(categorias)}``")
    embed.set_footer(text=inter.guild.name, icon_url=inter.guild.icon)

    options = []
    if categorias:
        for categoriaID in categorias:
            categoria = ObterCategoria(categoriaID)
            if categoria:
                options.append(
                    disnake.SelectOption(
                        label=categoria["title"],
                        emoji=categoria["emoji"],
                        value=categoriaID
                    )
                )

    if not options:
        options = [
            disnake.SelectOption(
                label="Nenhuma categoria disponível",
                emoji="❌",
                value="none"
            )
        ]

    select = disnake.ui.StringSelect(
        placeholder="Selecione uma categoria para editar",
        custom_id="EditarCategoriaTicket",
        options=options,
        disabled=True if len(categorias) == 0 else False
    )

    components = [
        select,
        disnake.ui.Button(style=disnake.ButtonStyle.green, label="Criar categoria", emoji=mais2, custom_id="CriarNovaCategoria"),
        disnake.ui.Button(label="Voltar", emoji=voltar, custom_id="GerenciarPainelTicket"),
    ]

    return embed, components

class CriarCategoriaModal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.TextInput(
                label="Título da categoria",
                custom_id="title",
                required=True,
                style=TextInputStyle.short,
            ),
            disnake.ui.TextInput(
                label="Emoji da categoria",
                custom_id="emoji",
                required=False,
                style=TextInputStyle.short,
            ),
        ]
        super().__init__(title="Criar Categoria", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        await inter.response.edit_message(f"{carregarAnimado} Carregando informações", embed=None, components=None)
        db = ObterDatabase()
        ticket = db["tickets"]["1"]
        title = inter.text_values["title"]
        emoji = inter.text_values["emoji"]
        CriarCategoria(title, emoji)
        embed, components = ObterPainelCategorias(inter)
        await inter.edit_original_message(content=None, embed=embed, components=components)
        await inter.followup.send(f"{positivo} Categoria criada com sucesso", ephemeral=True, delete_after=3)        

class EditarCategoriaModal(disnake.ui.Modal):
    def __init__(self, categoria_id):
        db = ObterCategoria(categoria_id)
        title_value = db.get("title", "") if db else ""
        emoji_value = db.get("emoji", "") if db else ""

        components = [
            disnake.ui.TextInput(
                label="Título da categoria",
                custom_id="title",
                required=True,
                value=title_value,
                style=TextInputStyle.short,
            ),
            disnake.ui.TextInput(
                label="Emoji da categoria",
                custom_id="emoji",
                required=False,
                value=emoji_value,
                style=TextInputStyle.short,
            ),
            disnake.ui.TextInput(
                label="Apagar categoria (Y para apagar)",
                custom_id="apagar",
                min_length=1,
                max_length=1,
                required=False,
                value="N",
                style=TextInputStyle.short,
            ),
        ]

        super().__init__(title="Editar Categoria", components=components)
        self.categoria_id = categoria_id

    async def callback(self, inter: disnake.ModalInteraction):
        await inter.response.edit_message(f"{carregarAnimado} Carregando informações", embed=None, components=None)
        title = inter.text_values.get("title")
        emoji = inter.text_values.get("emoji")
        apagar = inter.text_values.get("apagar").strip().upper()

        file_path = "Database/Tickets/ticket.json"

        with open(file_path, "r", encoding="utf-8") as file:
            data = json.load(file)

        if emoji == "": emoji = None

        for ticket_id, ticket_data in data.get("tickets", {}).items():
            categorias = ticket_data.get("categorias", {})
            if self.categoria_id in categorias:

                if apagar == "Y":
                    del categorias[self.categoria_id]
                    mensagem = f"{positivo} A categoria foi apagada com sucesso."
                else:
                    categorias[self.categoria_id]["title"] = title
                    categorias[self.categoria_id]["emoji"] = emoji
                    mensagem = f"{positivo} A categoria foi atualizada com sucesso."

                with open(file_path, "w", encoding="utf-8") as file:
                    json.dump(data, file, indent=4, ensure_ascii=False)


                embed, components = ObterPainelCategorias(inter)
                await inter.edit_original_message(content=None, embed=embed, components=components)
                await inter.followup.send(mensagem, ephemeral=True, delete_after=3)
                break

class AlterarInformaçõesMensagem(disnake.ui.Modal):
    def __init__(self):
        db = ObterDatabase()
        ticket = db["tickets"]["1"]
        msg = ticket["embed"]["content"]
        components = [
            disnake.ui.TextInput(
                label="Mensagem",
                placeholder="Customize a mensagem que será enviada junto com a embed ",
                custom_id="msg",
                required=False,
                value=msg,
                style=TextInputStyle.paragraph,
            ),
        ]
        super().__init__(title="Customizar Mensagem", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        await inter.response.edit_message(f"{carregarAnimado} Carregando informações", embed=None, components=None)
        db = ObterDatabase()
        ticket = db["tickets"]["1"]
        msg = inter.text_values["msg"]

        ticket["embed"]["content"] = msg

        with open("Database/Tickets/ticket.json", "w") as newf:
            json.dump(db, newf, indent=4)
        
        embeds, components = ObterPainelTicket(inter)
        await inter.edit_original_message(content=None, embeds=embeds, components=components)
        await inter.followup.send(f"{positivo} Mensagem atualizada com sucesso", ephemeral=True, delete_after=3)

class AlterarInformaçõesEmbed(disnake.ui.Modal):
    def __init__(self):
        db = ObterDatabase()
        ticket = db["tickets"]["1"]
        title = ticket["embed"]["title"]
        desc = ticket["embed"]["desc"]
        color = ticket["embed"]["color"]
        banner = ticket["embed"]["banner"]

        components = [
            disnake.ui.TextInput(
                label="Título",
                placeholder="Coloque o título do embed",
                custom_id="title",
                style=TextInputStyle.short,
                max_length=50,
                required=False,
                value=title
            ),
            disnake.ui.TextInput(
                label="Descrição",
                placeholder="Customize a descrição que será enviada na embed",
                custom_id="desc",
                style=TextInputStyle.paragraph,
                required=False,
                value=desc
            ),
            disnake.ui.TextInput(
                label="Cor (#FFFFFF -> Hex)",
                placeholder="Coloque a cor da embed em HEX",
                custom_id="color",
                style=TextInputStyle.short,
                min_length=7,
                max_length=7,
                required=False,
                value=color
            ),
            disnake.ui.TextInput(
                label="URL do Banner",
                placeholder="Insira o URL da imagem do banner (opcional)",
                custom_id="banner",
                style=TextInputStyle.short,
                required=False,
                value=banner
            ),
        ]
        super().__init__(title="Customizar Embed", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        await inter.response.edit_message(f"{carregarAnimado} Carregando informações", embed=None, components=None)
        db = ObterDatabase()
        ticket = db["tickets"]["1"]

        ticket["embed"]["title"] = inter.text_values["title"]
        ticket["embed"]["desc"] = inter.text_values["desc"]
        ticket["embed"]["color"] = inter.text_values["color"]
        ticket["embed"]["banner"] = inter.text_values["banner"]

        with open("Database/Tickets/ticket.json", "w") as f:
            json.dump(db, f, indent=4)

        embeds, components = ObterPainelTicket(inter)
        await inter.edit_original_message(content=None, embeds=embeds, components=components)
        await inter.followup.send(f"{positivo} Mensagem atualizada com sucesso", ephemeral=True, delete_after=3)

def ObterPainelTicket(inter: disnake.MessageInteraction):
    db = ObterDatabase()
    ticket = db["tickets"]["1"]
    title = db["tickets"]["1"]["embed"]["title"]
    desc = db["tickets"]["1"]["embed"]["desc"]
    banner = db["tickets"]["1"]["embed"]["banner"]
    color = db["tickets"]["1"]["embed"]["color"]
    color = int(color.lstrip("#"), 16)

    if not title: title = "Não configurado"
    if not desc: desc = f"{negativo} ``Descrição não configurada``"
    if not banner: banner = None

    embed = disnake.Embed(
        title="Gerenciar Sistema de Ticket",
        description="Utilize este painel para gerenciar o sistema de Ticket.\nVocê pode ter apenas 1 ticket, porém várias categorias.",
        timestamp=datetime.now(),
        color=disnake.Color(0x00FFFF)
    )
    embed.add_field(name="Categorias Disponíveis", value=f"{caixa} ``{len(ticket['categorias'])}``")
    embed.set_footer(text=inter.guild.name, icon_url=inter.guild.icon)
    embed.set_thumbnail(url="https://media.discordapp.net/attachments/1327815504865398854/1333664443258900583/a_d78e7542df8823e9c10eac06609d7473.gif?ex=6799b74d&is=679865cd&hm=cc1bcb51d18a4241a072849d1e82f28b030d61c0912f42d57174698a01c91d61&=")

    embedPreview = disnake.Embed(
        title=title,
        description=desc,
        timestamp=datetime.now(),
        color=disnake.Color(color)
    )
    embedPreview.set_footer(text=inter.guild.name, icon_url=inter.guild.icon)
    embedPreview.set_image(url=banner)

    embeds = [embed, embedPreview]

    select = disnake.ui.StringSelect(
        placeholder="Selecione uma opção para editar",
        custom_id="CustomizarPainelTicketDropdown",
        options=[
            disnake.SelectOption(
                label="Customizar Mensagem",
                value="EditarMensagemTicketOption",
                emoji=mensagem,
                description="Editar Mensagem do Ticket"
            ),
            disnake.SelectOption(
                label="Customizar Embed",
                value="EditarEmbedTicketOption",
                emoji=embedE,
                description="Editar Embed do Ticket"
            ),
        ]
    )

    components = [
        select,
        [
        disnake.ui.Button(label="Gerenciar Categorias", emoji=diretorio, custom_id="CustomizarCategoriasTicket", style=disnake.ButtonStyle.blurple),
        disnake.ui.Button(label="Enviar Mensagem", emoji=arrow, custom_id="EnviarMensagemTicket", style=disnake.ButtonStyle.green),
        ],
        [
            disnake.ui.Button(label="Sincronizar Mensagem", emoji=reload, custom_id="SincronizarMensagemTicket"),
            disnake.ui.Button(label="Voltar", emoji=voltar, custom_id="PainelInicial"),
        ]
    ]

    return embeds, components

def obterMensagemTicket(inter: disnake.MessageInteraction):
    db = ObterDatabase()
    ticket = db["tickets"]["1"]
    categorias = ticket["categorias"]
    msg = db["tickets"]["1"]["embed"]["content"]
    title = db["tickets"]["1"]["embed"]["title"]
    desc = db["tickets"]["1"]["embed"]["desc"]
    banner = db["tickets"]["1"]["embed"]["banner"]
    color = db["tickets"]["1"]["embed"]["color"]
    color = int(color.lstrip("#"), 16)

    if not color: color = 0x00FFFF
    if not title: title = None
    if not desc: desc = None
    if not banner: banner = None

    embedPreview = disnake.Embed(
        title=title,
        description=desc,
        timestamp=datetime.now(),
        color=disnake.Color(color)
    )
    embedPreview.set_footer(text=inter.guild.name, icon_url=inter.guild.icon)
    embedPreview.set_image(url=banner)

    options = []
    if categorias:
        for categoriaID in categorias:
            categoria = ObterCategoria(categoriaID)
            if categoria:
                options.append(
                    disnake.SelectOption(
                        label=categoria["title"],
                        emoji=categoria["emoji"],
                        value=categoriaID
                    )
                )

    if not options:
        options = [
            disnake.SelectOption(
                label="Nenhuma categoria disponível",
                emoji="❌",
                value="none"
            )
        ]

    select = disnake.ui.StringSelect(
        placeholder="Selecione uma categoria para abrir",
        custom_id="AbrirCategoriaDropdown",
        options=options,
        disabled=True if len(categorias) == 0 else False
    )

    return msg, embedPreview, select

async def EnviarMensagemTicket(inter: disnake.MessageInteraction):
    canal = inter.values[0]  # -> canal onde o painel será enviado
    canal = inter.guild.get_channel(int(canal))

    msg, embed, components = obterMensagemTicket(inter)
    msg = await canal.send(content=msg, embed=embed, components=components)
    await inter.response.edit_message(f"{positivo} Mensagem enviada com sucesso em {canal.mention} | {msg.jump_url}", components=None)
    db = ObterDatabase()

    if isinstance(db.get("tickets", {}).get("1", {}).get("ids", []), list):
        db["tickets"]["1"]["ids"].append(f"{msg.channel.id}_{msg.id}")
    else:
        db["tickets"]["1"]["ids"] = [f"{msg.channel.id}_{msg.id}"]

    with open("Database/Tickets/ticket.json", "w") as f:
        json.dump(db, f, indent=4)

async def SincronizarMensagemTicket(inter: disnake.MessageInteraction):
    await inter.response.send_message(content=f"{carregarAnimado} Sincronizando mensagens", ephemeral=True)
    msg, embed, components = obterMensagemTicket(inter)
    db = ObterDatabase()

    msgsParaSincronizar = len(db["tickets"]["1"]["ids"])
    msgSincronizadas = 0
    novos_ids = []
    for ids in db["tickets"]["1"]["ids"]:
        channelID, messageID = ids.split("_")
        if channelID:
            channel = inter.guild.get_channel(int(channelID))
            if channel:
                oldmsg = await channel.fetch_message(int(messageID))
                if oldmsg:
                    await oldmsg.delete()
                
                newmsg = await channel.send(content=msg, embed=embed, components=components)
                novos_ids.append(f"{newmsg.channel.id}_{newmsg.id}")
                msgSincronizadas += 1

    db["tickets"]["1"]["ids"] = novos_ids
    with open("Database/Tickets/ticket.json", "w") as f:
        json.dump(db, f, indent=4)

    await inter.edit_original_message(f"{positivo} Mensagens sincronizadas com sucesso ({msgsParaSincronizar}/{msgSincronizadas})")

async def abrirCategoria(inter: disnake.MessageInteraction, categoriaID):
    db = ObterDatabase()
    ticket = db["tickets"]["1"]
    ticket_name = ticket["embed"]["title"]
    if not ticket_name: ticket_name = "Não definido"
    categoria = ObterCategoria(categoriaID)
    categoria_nome = categoria["title"]

    topic = await inter.channel.create_thread(
        name=f"🚧・{inter.user.name} ・ {categoria_nome}",
        type=disnake.ChannelType.private_thread,
        reason=f"[Ease Bot] Criar ticket (Categoria: {categoria_nome} | Usuário: {inter.user.name})",
        invitable=False
    )

    embed = disnake.Embed(
        color=disnake.Color.blurple(),
        timestamp=datetime.now()
    )
    embed.set_author(name=f"{inter.user.name}", icon_url=inter.user.avatar)
    embed.set_thumbnail(url="https://media.discordapp.net/attachments/1327815504865398854/1333664443258900583/a_d78e7542df8823e9c10eac06609d7473.gif?ex=6799b74d&is=679865cd&hm=cc1bcb51d18a4241a072849d1e82f28b030d61c0912f42d57174698a01c91d61&=")
    embed.add_field(name=f"{diretorio} Nome da categoria", value=f"```{categoria_nome}```", inline=False)
    embed.add_field(name=f"{mensagem} Ticket", value=f"`{ticket_name}`", inline=True)
    embed.add_field(name=f"{user} Aberto por", value=f"{inter.user.mention}", inline=True)
    embed.add_field(name=f"{clock} Aberto em", value=f"<t:{int(datetime.now().timestamp())}:R>", inline=True)
    embed.set_footer(text=f"{inter.guild.name} | © Ease Solutions", icon_url=inter.guild.icon)

    TicketAbertoID = GerarString()
    components = [
        disnake.ui.StringSelect(
            placeholder="Gerenciar o Painel Staff",
            custom_id=f"PainelStaffTicketID_{TicketAbertoID}",
            options=[
                disnake.SelectOption(label="Lembrar", description="Lembrar o usuário do Ticket", value="LembrarUser", emoji=clock),
                disnake.SelectOption(label="Fechar", description="Fechar o Ticket aberto", value="FecharTicket", emoji=apagar),
            ]
        )
    ]

    novo_ticket = {
        "id": TicketAbertoID,
        "user": f"{inter.user.id}",
        "categoriaID": f"{categoriaID}",
        "ticket_name": f"{ticket_name}",
        "topic_id": f"{topic.id}"
    }

    with open("Database/Tickets/ticketsAbertos.json", "r") as tickets_abertos_file:
        tickets_abertos_db = json.load(tickets_abertos_file)

    tickets_abertos_db[TicketAbertoID] = novo_ticket

    with open("Database/Tickets/ticketsAbertos.json", "w") as tickets_abertos_file:
        json.dump(tickets_abertos_db, tickets_abertos_file, indent=4)

    with open("Database/Server/cargos.json") as db:
        cargos = json.load(db)
    
    with open("config.json") as config:
        confdb = json.load(config)
        owner = confdb["owner"]

    suporte = cargos["suporte"]
    if not suporte: suporte = f"<@{owner}>"
    else: suporte = f"<@&{suporte}>"
    content = f"{inter.user.mention} {suporte}"

    await topic.send(
        content=content,
        embed=embed,
        components=components
    )

    await inter.edit_original_response(f"{positivo} Seu ticket foi aberto: {topic.mention}", components=[disnake.ui.Button(label="Acessar Ticket", url=topic.jump_url)])

    with open("Database/Server/canais.json") as f:
        canais = json.load(f)
        logs = canais["tickets"]

    embed = disnake.Embed(
        title=f"Ticket Criado ・ {categoria_nome}",
        description="Um novo ticket foi aberto; Consulte as informações sobre abaixo.",
        timestamp=datetime.now(),
        color=disnake.Color(0x00FFFF)
    )
    embed.add_field(name=f"{diretorio} Nome da categoria", value=f"```{categoria_nome}```", inline=False)
    embed.add_field(name=f"{mensagem} Ticket", value=f"`{ticket_name}`", inline=True)
    embed.add_field(name=f"{user} Criador", value=f"{inter.user.mention}", inline=True)
    embed.add_field(name=f"{clock} Criado em", value=f"<t:{int(datetime.now().timestamp())}:R>", inline=True)

    if logs:
        canal = inter.guild.get_channel(int(logs))
        if canal:
            await canal.send(embed=embed, components=[disnake.ui.Button(label="Acessar Ticket", url=topic.jump_url)])

async def lembrar_usuario(inter: disnake.MessageInteraction, ticket_id: str):
    with open("Database/Tickets/ticketsAbertos.json", "r") as tickets_file:
        tickets_db = json.load(tickets_file)

    ticket_data = tickets_db.get(ticket_id)
    user_id = ticket_data.get("user")
    topic_id = ticket_data.get("topic_id")
    guild = inter.guild

    user = guild.get_member(int(user_id))
    topic = guild.get_thread(int(topic_id))

    try:
        embed = disnake.Embed(
            title=f"{clock} Lembrete de Ticket Pendente",
            description=(
                f"**{user.name}**, você possui um ticket pendente."
                "Se não for respondido, poderá ser fechado."
            ),
            color=disnake.Color.blurple()
        )
        embed.add_field(name="Acessar Ticket", value=f"[Clique aqui para acessar o ticket]({topic.jump_url})")

        await user.send(embed=embed, components=[disnake.ui.Button(label="Acessar Ticket", url=topic.jump_url)])
        await inter.edit_original_message(f"{positivo} Lembrete enviado para {user.mention}.")
    except disnake.Forbidden:
        await inter.edit_original_message(f"{negativo} Não foi possível enviar mensagem para o usuário. As mensagens diretas podem estar desativadas.", ephemeral=True)

async def fechar_ticket(inter: disnake.MessageInteraction, ticket_id: str):
    with open("Database/Tickets/ticketsAbertos.json", "r") as tickets_file:
        tickets_db = json.load(tickets_file)

    ticket_data = tickets_db.get(ticket_id)
    db = ObterDatabase()
    ticket = db["tickets"]["1"]
    ticket_name = ticket["embed"]["title"]
    if not ticket_name: ticket_name = "Não definido"
    categoria = ObterCategoria(ticket_data["categoriaID"])
    categoria_nome = categoria["title"]
    topic_id = ticket_data.get("topic_id")
    guild = inter.guild

    topic = guild.get_thread(int(topic_id))

    await topic.delete()
    tickets_db.pop(ticket_id, None)

    with open("Database/Tickets/ticketsAbertos.json", "w") as tickets_file:
        json.dump(tickets_db, tickets_file, indent=4)
    
    with open("Database/Server/canais.json") as f:
        canais = json.load(f)
        logs = canais["tickets"]

    embed = disnake.Embed(
        title=f"Ticket Fechado ・ {categoria_nome}",
        description="Um ticket foi fechado; Consulte as informações sobre abaixo.",
        timestamp=datetime.now(),
        color=disnake.Color(0x00FFFF)
    )
    embed.add_field(name=f"{diretorio} Nome da categoria", value=f"```{categoria_nome}```", inline=False)
    embed.add_field(name=f"{user} Criador", value=f"<@{ticket_data["user"]}>", inline=True)
    embed.add_field(name=f"{safety} Fechado por", value=f"{inter.user.mention}", inline=True)
    embed.add_field(name=f"{clock} Fechado em", value=f"<t:{int(datetime.now().timestamp())}:R>", inline=True)
    embed.set_footer(text=f"{inter.guild.name} | © Ease Solutions", icon_url=inter.guild.icon)

    if logs:
        canal = inter.guild.get_channel(int(logs))
        if canal:
            await canal.send(embed=embed)
    
    embedUser = disnake.Embed(
        title=f"{apagar} Ticket Fechado",
        description=f"Seu ticket foi fechado por um moderador; Consulte as informações abaixo para saber mais.",
        timestamp=datetime.now(),
        color=disnake.Color(0x00FFFF)
    )
    embedUser.add_field(name=f"{safety} Fechado por", value=f"{inter.user.mention}", inline=True)
    embedUser.add_field(name=f"{clock} Fechado em", value=f"<t:{int(datetime.now().timestamp())}:R>", inline=True)
    embedUser.set_footer(text=f"{inter.guild.name} | © Ease Solutions", icon_url=inter.guild.icon)
    embedUser.set_thumbnail(url="https://media.discordapp.net/attachments/1327815504865398854/1333664443258900583/a_d78e7542df8823e9c10eac06609d7473.gif?ex=6799b74d&is=679865cd&hm=cc1bcb51d18a4241a072849d1e82f28b030d61c0912f42d57174698a01c91d61&=")

    usuario = inter.guild.get_member(int(ticket_data["user"]))
    if usuario:
        try:
            await usuario.send(embed=embedUser)
        except: pass

class TicketCommand(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.slash_command()
    async def ticket(self, inter):
        pass

    @ticket.sub_command()
    async def close(self, inter: disnake.ApplicationCommandInteraction):
        """Close a specific ticket"""
        await inter.response.defer(ephemeral=True)
        if verificar_permissao(inter.user.id):
            if not isinstance(inter.channel, disnake.Thread):
                await inter.followup.send(f"{negativo} Este comando só pode ser usado em tópicos de tickets.", ephemeral=True)
                return

            topic_id = str(inter.channel.id)

            with open("Database/Tickets/ticketsAbertos.json", "r") as tickets_file:
                tickets_db = json.load(tickets_file)

            ticket_id = None
            ticket_data = None
            for t_id, t_data in tickets_db.items():
                if t_data.get("topic_id") == topic_id:
                    ticket_id = t_id
                    ticket_data = t_data
                    break

            if not ticket_data:
                await inter.followup.send(f"{negativo} Este tópico não está associado a nenhum ticket aberto.", ephemeral=True)
                return

            await inter.channel.delete(reason=f"[Ease Bot] Ticket fechado por {inter.user.name}")
            tickets_db.pop(ticket_id, None)

            with open("Database/Tickets/ticketsAbertos.json", "w") as tickets_file:
                json.dump(tickets_db, tickets_file, indent=4)

            with open("Database/Server/canais.json") as f:
                canais = json.load(f)
                logs = canais.get("tickets")

            categoria = ObterCategoria(ticket_data["categoriaID"])
            categoria_nome = categoria["title"] if categoria else "Categoria desconhecida"

            embed = disnake.Embed(
                title=f"Ticket Fechado ・ {categoria_nome}",
                description="Um ticket foi fechado; Consulte as informações sobre abaixo.",
                timestamp=datetime.now(),
                color=disnake.Color(0x00FFFF)
            )
            embed.add_field(name=f"{diretorio} Nome da categoria", value=f"```{categoria_nome}```", inline=False)
            embed.add_field(name=f"{user} Criador", value=f"<@{ticket_data["user"]}>", inline=True)
            embed.add_field(name=f"{safety} Fechado por", value=f"{inter.user.mention}", inline=True)
            embed.add_field(name=f"{clock} Fechado em", value=f"<t:{int(datetime.now().timestamp())}:R>", inline=True)
            embed.set_footer(text=f"{inter.guild.name} | © Ease Solutions", icon_url=inter.guild.icon)

            if logs:
                canal = inter.guild.get_channel(int(logs))
                if canal:
                    await canal.send(embed=embed)

        else:
            await inter.followup.send(f"{negativo} Faltam permissões", ephemeral=True)

    @ticket.sub_command()
    async def closeall(self, inter: disnake.ApplicationCommandInteraction):
        """Use to close/delete all tickets"""
        if verificar_permissao(inter.user.id):
            await inter.response.defer(ephemeral=True)

            with open("Database/Tickets/ticketsAbertos.json", "r") as tickets_file:
                tickets_db = json.load(tickets_file)

            guild = inter.guild
            deleted_tickets = 0

            for ticket_id, ticket_data in list(tickets_db.items()):
                topic_id = ticket_data.get("topic_id")
                topic = guild.get_thread(int(topic_id)) if topic_id else None

                if topic:
                    await topic.delete(reason=f"[Ease Bot] Todos os tickets fechados por {inter.user.name}")
                    tickets_db.pop(ticket_id, None)
                    deleted_tickets += 1

            with open("Database/Tickets/ticketsAbertos.json", "w") as tickets_file:
                json.dump(tickets_db, tickets_file, indent=4)

            await inter.followup.send(f"{positivo} {deleted_tickets} tickets foram fechados com sucesso.", ephemeral=True)
        else:
            await inter.response.send_message(f"{negativo} Faltam permissões.", ephemeral=True)

    @ticket.sub_command()
    async def resolvido(self, inter: disnake.MessageCommandInteraction):
        """Use to mark the ticket as resolved"""
        if verificar_permissao(inter.user.id):
            if inter.channel.type in (disnake.ChannelType.public_thread, disnake.ChannelType.private_thread):
                await inter.response.send_message(f"{carregarAnimado} Aguarde um momento", ephemeral=True)

                embed1 = disnake.Embed(
                    title="Ticket Resolvido",
                    description="O ticket atual foi marcado como resolvido por um moderador. Mensagens não podem mais ser enviadas, portanto interações não podem ser feitas.",
                    color=disnake.Color(0x5A9F68),
                    timestamp=datetime.now()
                )

                embed1.add_field(name=f"{user} Fechado por", value=f"{inter.user.mention}")
                embed1.set_thumbnail(url="https://media.discordapp.net/attachments/1327815504865398854/1333664443258900583/a_d78e7542df8823e9c10eac06609d7473.gif?ex=6799b74d&is=679865cd&hm=cc1bcb51d18a4241a072849d1e82f28b030d61c0912f42d57174698a01c91d61&=")
                embed1.set_footer(text=f"{inter.guild.name} | © Ease Solutions", icon_url=inter.guild.icon)

                await inter.channel.send(embed=embed1)
                await inter.channel.edit(locked=True, archived=True, reason=f"[Ease Bot] Trancar Ticket (Moderador: {inter.user.name})")

                with open("Database/Server/canais.json") as f:
                    canais = json.load(f)
                    logs = canais["tickets"]
            
                embed2 = disnake.Embed(
                    title="Ticket marcado como Resolvido",
                    description="Um ticket foi marcado como resolvido por um moderador. Mensagens não podem mais ser enviadas;",
                    color=disnake.Color(0x5A9F68),
                    timestamp=datetime.now()
                )

                embed2.add_field(name=f"{user} Fechado por", value=f"{inter.user.mention}", inline=True)
                embed2.add_field(name=f"{clock} Fechado em", value=f"<t:{int(datetime.now().timestamp())}:R>", inline=True)
                embed2.set_thumbnail(url="https://media.discordapp.net/attachments/1327815504865398854/1333664443258900583/a_d78e7542df8823e9c10eac06609d7473.gif?ex=6799b74d&is=679865cd&hm=cc1bcb51d18a4241a072849d1e82f28b030d61c0912f42d57174698a01c91d61&=")
                embed2.set_footer(text=f"{inter.guild.name} | © Ease Solutions", icon_url=inter.guild.icon)

                if logs:
                    canal = inter.guild.get_channel(int(logs))
                    if canal:
                        await canal.send(embed=embed2, components=[disnake.ui.Button(label="Acessar Ticket", url=inter.channel.jump_url)])
            else:
                await inter.response.send_message(f"{negativo} O canal não é um ticket.", ephemeral=True, delete_after=3)
        else:
            await inter.response.send_message(f"{negativo} Faltam permissões.", ephemeral=True)

    @commands.Cog.listener("on_button_click")
    async def TicketButtonListener(self, inter: disnake.MessageInteraction):
        if inter.component.custom_id == "GerenciarPainelTicket":
            await inter.response.edit_message(f"{carregarAnimado} Carregando informações", embed=None, components=None)
            embeds, components = ObterPainelTicket(inter)
            await inter.edit_original_message(content=None, embeds=embeds, components=components)

        elif inter.component.custom_id == "CustomizarCategoriasTicket":
            await inter.response.edit_message(f"{carregarAnimado} Carregando informações", embed=None, components=None)
            embed, components = ObterPainelCategorias(inter)
            await inter.edit_original_message(content=None, embed=embed, components=components)
        
        elif inter.component.custom_id == "CriarNovaCategoria":
            await inter.response.send_modal(CriarCategoriaModal())
        
        elif inter.component.custom_id == "EnviarMensagemTicket":
            components = disnake.ui.ChannelSelect(
                custom_id="EnviarPainelTicketDropdown",
                placeholder="Selecione o canal onde o ticket será enviado",
                channel_types=[ChannelType.text]
            )
            await inter.response.send_message(components=components, ephemeral=True)
        
        elif inter.component.custom_id == "SincronizarMensagemTicket":
            await SincronizarMensagemTicket(inter)


    @commands.Cog.listener("on_dropdown")
    async def TicketDropdownListener(self, inter: disnake.MessageInteraction):
        if inter.component.custom_id == "CustomizarPainelTicketDropdown":
            if inter.values[0] == "EditarMensagemTicketOption": await inter.response.send_modal(AlterarInformaçõesMensagem())
            elif inter.values[0] == "EditarEmbedTicketOption": await inter.response.send_modal(AlterarInformaçõesEmbed())

        elif inter.component.custom_id == "EditarCategoriaTicket":
            await inter.response.send_modal(EditarCategoriaModal(inter.values[0]))

        elif inter.component.custom_id == "EnviarPainelTicketDropdown":
            await EnviarMensagemTicket(inter)
        
        elif inter.component.custom_id == "AbrirCategoriaDropdown":
            await inter.response.send_message(f"{carregarAnimado} Estamos abrindo seu ticket, aguarde um momento", ephemeral=True)
            await abrirCategoria(inter, categoriaID=inter.values[0])

        elif inter.component.custom_id.startswith("PainelStaffTicketID_"):
            await inter.response.send_message(f"{carregarAnimado} Aguarde um momento", ephemeral=True)
            id = inter.component.custom_id.replace("PainelStaffTicketID_", "")
            with open("Database/Server/cargos.json") as f:
                cargos = json.load(f)
                adm = int(cargos["administrador"])
                suporte = int(cargos["suporte"])
            
            user_roles_ids = [role.id for role in inter.user.roles]

            if adm in user_roles_ids:
                if inter.values[0] == "LembrarUser":
                    await lembrar_usuario(inter, id)
                elif inter.values[0] == "FecharTicket":
                    await fechar_ticket(inter, id)
            else:
                await inter.edit_original_message(f"{negativo} Você não tem as permissões necessárias.")
                

def setup(bot: commands.Bot):
    bot.add_cog(TicketCommand(bot))